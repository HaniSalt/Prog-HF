#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include "debugmalloc.h"
#pragma warning (disable:4996)

#ifndef olvasok
#define olvasok
typedef struct reader {

	struct name
	{
		char first_name[100 + 1];
		char last_name[100 + 1];
	}name;
	int age;
	char ID[4];
	char book_rented[1000];

}reader;

int number_of_lines();

void rent2(reader r);

void rent();

void display(void);

void create();

void reader_info();
#endif 
