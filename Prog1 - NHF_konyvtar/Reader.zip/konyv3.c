#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include "konyv.h"
#pragma warning (disable:4996)

void title_search()
{
	char string[500];
	char konyvek[100] = { 0 };
	char buffer[2000];
	while (konyvek[0] != '0')
	{
		FILE* fp = fopen("konyvek.txt", "r");
		if (fp == NULL)
		{
			printf("Error file missing\n");
			exit(-1);
		}

		printf("Please enter a title (0 to end)\n");
		scanf("%s", konyvek);
		while (fscanf(fp, "%s", string) == 1)
		{
			if (konyvek[0] == '0')
			{
				break;
			}

			if (islower(konyvek[0]))
			{
				konyvek[0] = toupper(konyvek[0]);
			}

			if (strstr(string, konyvek) != 0)
			{
				fgets(buffer, 2000, fp);
				printf("%s%s\n", konyvek, buffer);
			}
		}
		fclose(fp);
	}
}
void author_search()
{

}
void genre_search()
{

}

void date_search()
{

}


void search(void)
{

	char str[50];
	int option;
	printf("Please choose in what way you want to search:\n");
	do
	{
		printf("Type:\n1 (Search by title)\n"
			"2 (Search by author)\n"
			"3 (Search by genre)\n"
			"4 (Search by date of release)\n"
			"9 (Exit)\n\n");

		scanf("%s", &str);
		option = (int)strtol(str, NULL, 10);
		switch (option)
		{
		case 1:
			printf("\n");
			title_search();
			break;
		case 2:
			author_search();
			printf("\n");
			break;
		case 3:
			genre_search();
			printf("\n");
			break;
		case 4:
			date_search();
			printf("\n");
			break;
		default:
			if (option != 9)
			{
				printf("Invalid input!");
				break;
			}
		}
		printf("\n\n");
	} while (option != 9);
}



