#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
//#include "konyv2.h"
#include "debugmalloc.h"
#pragma warning (disable:4996)

#ifndef konyv1
#define konyv1
/* Struct for date */
typedef struct date {

	int ev, honap, nap;

}date;

int num_lines();

char* dinamikus_tomb();

void view(void);

void add(int which_line);

void delete_book(int delete_line);

void choose_book();

void edit();

void title_search();

void author_search();

void genre_search();

void date_search();

#endif
